// Ed25519 public key that verifies on-prem license keys. Replaced by `node scripts/license.js keygen`.
// (Empty = licensing not configured yet; on-prem installs run in 30-day trial mode.)
export const LICENSE_PUBLIC_KEY = '';
